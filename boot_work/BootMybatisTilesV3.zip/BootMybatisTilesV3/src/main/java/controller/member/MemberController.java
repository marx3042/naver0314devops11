package controller.member;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import data.service.MemberService;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class MemberController {
	@NonNull
	private MemberService service;
	
	@GetMapping("/member/list")
	public String memberList(Model model) {
		int totalCount = service.getTotalMemberCount();
		model.addAttribute("totalCount", totalCount);
		
		return "member/memberlist";
	}
}
